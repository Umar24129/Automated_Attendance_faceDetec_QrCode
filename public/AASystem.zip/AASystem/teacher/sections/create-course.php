<!-- Adding Course section -->
	<div class="container-fliud">
		<div class="row">
			<!-- Starting the Form -->
			<div style="margin-left: 27%;margin-top:5%;">
				<div class="card text-center mt-4">
				  <div class="card-header">
				    Add Course
				  </div>
				  <form >
					  <div class="card-body">
					    <h5 class="card-title">Course Details</h5>
					    <div class="input-group mb-3">
						  <div class="input-group-prepend">
						    <span class="input-group-text" id="inputGroup-sizing-default">Course Code.</span>
						  </div>
						  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
						</div>
						<div class="input-group mb-3">
						  <div class="input-group-prepend">
						    <span class="input-group-text" id="inputGroup-sizing-default">Course Name</span>
						  </div>
						  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
						</div>
						<div class="input-group mb-3">
						  <div class="input-group-prepend">
						    <span class="input-group-text" id="inputGroup-sizing-default">Credit Hours..</span>
						  </div>
						  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
						</div>
					    <input type="submit" value="Add Course" class=" form-control btn btn-dark">
					  </div>
				  </form>
				</div>
			</div>
		</div>
	</div>
<!-- Course Section Ends Here-->