<?php
	include "sections/head.php";
	include "sections/dashboard-content.php";
	include "sections/foot.php";
?>