<div class="card" style="width: 25rem;margin-top: 5em;margin-left: 22em;">
  <div class="card-header">
    Delete Teacher
  </div>
  <div class="card-body">
    <form>
    <div class="form-group">
      <label for="exampleInputEmail1">Teacher Name</label>
      <input type="text" class="form-control" id="teacehr-name" aria-describedby="emailHelp" placeholder="Enter Teacher Name">
    </div>
    <button type="submit" class="btn btn-primary">Delete</button>
  </form>
  </div>
</div>