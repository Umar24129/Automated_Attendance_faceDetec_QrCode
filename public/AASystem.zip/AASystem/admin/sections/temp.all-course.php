<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Course Name</th>
      <th scope="col">Course Code</th>
      <th scope="col">Assigned To</th>
    </tr>
  </thead>
  <tbody>
   
  </tbody>
</table>