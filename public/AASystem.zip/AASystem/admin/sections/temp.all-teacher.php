<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Teacher Name</th>
      <th scope="col">Department</th>
      <th scope="col">Designation</th>
      <th scope="col">Contact</th>
    </tr>
  </thead>
  <tbody>
  
  </tbody>
</table>