<div class="card" style="width: 25rem;margin-top: 5em;margin-left: 22em;">
  <div class="card-header">
    Delete Course
  </div>
  <div class="card-body">
    <form>
	  <div class="form-group">
	    <label for="exampleInputEmail1">Course ID</label>
	    <input type="number" class="form-control" id="example" placeholder="Enter Course ID">
	  </div>
	  <button type="submit" class="btn btn-primary">Delete</button>
	</form>
  </div>
</div>