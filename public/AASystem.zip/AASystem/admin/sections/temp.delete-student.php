<div class="card" style="width: 25rem;margin-top: 5em;margin-left: 22em;">
  <div class="card-header">
    Delete Student
  </div>
  <div class="card-body">
    <form>
	  <div class="form-group">
	    <label for="exampleInputEmail1">Student ID</label>
	    <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Student ID">
	  </div>
	  <button type="submit" class="btn btn-primary">Delete</button>
	</form>
  </div>
</div>